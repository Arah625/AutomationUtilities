package org.autoutils.driver;

import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.options.XCUITestOptions;
import org.autoutils.driver.exception.InvalidMobilePlatformException;
import org.autoutils.driver.exception.UnknownPlatformException;
import org.openqa.selenium.WebDriver;

import java.net.URL;

public class MobileDriverFactory {

    /**
     * Get mobile driver for Android using UiAutomator2Options.
     *
     * @param options        The UiAutomator2Options for Android.
     * @param appiumServerUrl The URL of the Appium server.
     * @return The initialized Android WebDriver instance.
     */
    public static WebDriver getMobileDriver(UiAutomator2Options options, URL appiumServerUrl) {
        WebDriver driver = AndroidDriverManager.getInstance().getDriver(options, appiumServerUrl);
        DriverSessionManager.registerDriver(driver);
        System.out.println("Android driver initialized successfully.");
        return driver;
    }

    /**
     * Get mobile driver for iOS using XCUITestOptions.
     *
     * @param options        The XCUITestOptions for iOS.
     * @param appiumServerUrl The URL of the Appium server.
     * @return The initialized iOS WebDriver instance.
     */
    public static WebDriver getMobileDriver(XCUITestOptions options, URL appiumServerUrl) {
        WebDriver driver = IOSDriverManager.getInstance().getDriver(options, appiumServerUrl);
        DriverSessionManager.registerDriver(driver);
        System.out.println("iOS driver initialized successfully.");
        return driver;
    }

    /**
     * Get mobile driver automatically based on platform passed by the user.
     * This method switches between Android and iOS based on the platform passed as argument.
     *
     * @param platform        The platform specified (android or ios).
     * @param androidOptions  The UiAutomator2Options for Android.
     * @param iosOptions      The XCUITestOptions for iOS.
     * @param appiumServerUrl The URL of the Appium server.
     * @return The initialized WebDriver instance (Android or iOS).
     */
    public static WebDriver getMobileDriver(String platform, UiAutomator2Options androidOptions, XCUITestOptions iosOptions, URL appiumServerUrl) {
        if (platform == null || platform.isEmpty()) {
            throw new InvalidMobilePlatformException("Platform not provided.");
        }

        return switch (platform.toLowerCase()) {
            case "android" -> getMobileDriver(androidOptions, appiumServerUrl);
            case "ios" -> getMobileDriver(iosOptions, appiumServerUrl);
            default -> throw new UnknownPlatformException("Unsupported platform: " + platform);
        };
    }

    /**
     * Get mobile driver automatically by detecting the platform from configuration (as a fallback).
     * This method switches between Android and iOS based on the platform specified in the properties file.
     *
     * @param androidOptions  The UiAutomator2Options for Android.
     * @param iosOptions      The XCUITestOptions for iOS.
     * @param appiumServerUrl The URL of the Appium server.
     * @return The initialized WebDriver instance (Android or iOS).
     */
    public static WebDriver getMobileDriver(UiAutomator2Options androidOptions, XCUITestOptions iosOptions, URL appiumServerUrl) {
        String platform = ConfigManager.getPlatform();

        if (platform == null) {
            throw new InvalidMobilePlatformException("Platform not specified in configuration.");
        }

        return getMobileDriver(platform, androidOptions, iosOptions, appiumServerUrl);
    }
}
