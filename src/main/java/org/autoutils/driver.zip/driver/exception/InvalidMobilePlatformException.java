package org.autoutils.driver.exception;

public class InvalidMobilePlatformException extends RuntimeException{
    public InvalidMobilePlatformException(String message) {
        super(message);
    }
}
