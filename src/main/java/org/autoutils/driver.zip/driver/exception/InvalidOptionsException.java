package org.autoutils.driver.exception;

public class InvalidOptionsException extends RuntimeException {
    public InvalidOptionsException(String message) {
        super(message);
    }
}