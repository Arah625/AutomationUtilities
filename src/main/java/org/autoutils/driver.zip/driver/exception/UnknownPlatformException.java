package org.autoutils.driver.exception;

public class UnknownPlatformException extends RuntimeException {
    public UnknownPlatformException(String message) {
        super(message);
    }
}